<?php
/**
 * Plugin Name: Bulk Coupon Code Generator
 * Plugin URI: https://dsm.com/
 * Description: WP Setting and WP Widget Plugin.
 * Author: Dilip Modhavadiya
 * Author URI: https://dsm.com/
 * Version: 1.0.0
 * Text Domain: bulk-coupon-code-generator
 * Domain Path: /languages
 * License: GPL v2 - http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
if (!defined('ABSPATH')) {
    exit;
}
if( !defined( 'BCC_VERSION' ) ) {
	define( 'BCC_VERSION', '1.0.0' ); // Plugin Version
}
if( !defined( 'BCC_URL' ) ) {
    define( 'BCC_URL', plugin_dir_url( __FILE__ ) ); // Plugin url
}
if( !defined( 'BCC_PLUGIN_FILE' ) ) {
    define( 'BCC_PLUGIN_FILE', __FILE__ );
}

if ( ! defined( 'BCC_PLUGIN_DIR' ) )	    
{
    define( 'BCC_PLUGIN_DIR'   , plugin_dir_path( __FILE__ ) ); // Plugin Dir Path
}
/*
* Bulk Coupman Main File Call
*/
require_once( BCC_PLUGIN_DIR . '/includes/bulk-coupman-main.php' );