<?php
if ( isset( $_POST['generate_coupons'] ) ) {
        $email = sanitize_email( $_POST['customer_email'] );
        $product_ids = array_map( 'intval', explode( ',', $_POST['product_ids'] ) );
        $coupon_code = $this->custom_generate_coupon( $email, $product_ids );
        echo '<div class="notice notice-success is-dismissible"><p>Generated Coupon Code: ' . esc_html( $coupon_code ) . '</p></div>';
}
?>
<div class="wrap">
    <h1><?php _e('Bulk Coupon Generator','bulk-coupon-code-generator'); ?></h1>
        <form method="post" action="">
            <table class="form-table">
                <tbody>
                    <tr>
                        <th scope="row"><label for="customer_email"><?php _e('Email:','bulk-coupon-code-generator'); ?></label></th>
                        <td><input type="email" name="customer_email" id="customer_email" required class="regular-text"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="product_ids"><?php _e('Product IDs:','bulk-coupon-code-generator'); ?></label></th>
                        <td><input type="text" name="product_ids" id="product_ids" required class="regular-text" placeholder="e.g., 123, 456"></td>
                    </tr>
                </tbody>
            </table>
            <p><input type="submit" name="generate_coupons" value="Generate Coupon" class="button button-primary"></p>
        </form>
</div>
