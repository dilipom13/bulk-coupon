<?php
$args = array(
    'post_type' => 'shop_coupon',
    'post_status' => 'publish',
    'posts_per_page' => -1, // Retrieve all coupons
);
$coupons = get_posts($args);

if (!empty($coupons)) {
    ?>
    <h2><?php echo __('Existing Coupons', 'bulk-coupon-code-generator'); ?></h2>
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th><?php echo __('Coupon Code', 'bulk-coupon-code-generator'); ?></th>
                <th><?php echo __('Product IDs', 'bulk-coupon-code-generator'); ?></th>
                <th><?php echo __('Product Titles', 'bulk-coupon-code-generator'); ?></th>
                <th><?php echo __('Usage Count/Usage Limit', 'bulk-coupon-code-generator'); ?></th>
                <th><?php echo __('Email Restrictions', 'bulk-coupon-code-generator'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($coupons as $coupon) {
                $coupon_id = $coupon->ID;
                $product_ids = get_post_meta($coupon_id, 'product_ids', true);
                $product_ids = !empty($product_ids) ? explode(',', $product_ids) : [];
                $usage_count = get_post_meta($coupon_id, 'usage_count', true);
                $usage_limit = get_post_meta($coupon_id, 'usage_limit', true);
                $email_restrictions = get_post_meta($coupon_id, 'customer_email', true);
                $email_restrictions = is_array($email_restrictions) ? implode(", ", $email_restrictions) : __('None', 'bulk-coupon-code-generator');
                $product_titles = [];
                foreach ($product_ids as $product_id) {
                    $product = wc_get_product($product_id);
                    if ($product) {
                        $product_titles[] = $product->get_name();
                    }
                }
                $product_titles_str = !empty($product_titles) ? implode(", ", $product_titles) : __('None', 'bulk-coupon-code-generator');
                ?>
                <tr>
                    <td><?php echo esc_html($coupon->post_title); ?></td>
                    <td><?php echo esc_html(implode(", ", $product_ids)); ?></td>
                    <td><?php echo esc_html($product_titles_str); ?></td>
                    <td><?php echo esc_html($usage_count) . '/' . esc_html($usage_limit); ?></td>
                    <td><?php echo esc_html($email_restrictions); ?></td>
                </tr>
                <?php
            } ?>
        </tbody>
    </table>
    <?php
} else {
    echo '<p>' . __('No coupons found.', 'bulk-coupon-code-generator') . '</p>';
}