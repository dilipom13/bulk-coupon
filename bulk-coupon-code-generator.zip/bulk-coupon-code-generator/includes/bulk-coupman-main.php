<?php
class Bulk_Coupon_Code_Generator {

    public function __construct() {
        add_action( 'admin_notices', array( $this, 'woocommerce_missing_notice' ) );
        if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
            add_action( 'admin_menu', array( $this, 'custom_bulk_coupon_menu' ) );
        }
    }
    /**
     * WooCommerce Plugin Notice Will Display
    */
    public function woocommerce_missing_notice() {
        if ( ! self::is_woocommerce_active() ) {
            echo '<div class="error"><p>' . __('Bulk Coupon Code Generator requires WooCommerce to be installed and active.', 'bulk-coupon-code-generator') . '</p></div>';
        }
    }
    /**
     * Without WooCommerce Plugin will not active.
    */
    public static function on_activation() {
        if ( ! self::is_woocommerce_active() ) {
            deactivate_plugins( plugin_basename( BCC_PLUGIN_FILE ) );
            wp_die( __('This plugin requires WooCommerce to be installed and active.', 'bulk-coupon-code-generator'), 'Plugin dependency check', array( 'back_link' => true ) );
        }
    }
    /**
     * When Plugin Deactivate active_plugins Options Will remove
    */
    public static function on_deactivation() {
        delete_option('active_plugins');
    }
    /**
     * Check Woocommerce Plugin Active or Not.
    */
    public static function is_woocommerce_active() {
        include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
        return is_plugin_active( 'woocommerce/woocommerce.php' );
    }
    /**
     * Add admin menu item
    */
    public function custom_bulk_coupon_menu() {
        add_menu_page( 'Bulk Coupon Generator', 
                       'Bulk Coupons', 
                       'manage_options', 
                       'custom-bulk-coupon-generator', 
                       array( $this, 'custom_bulk_coupon_page' ), 
                       'dashicons-tickets-alt', 
                       6 );
       
        add_submenu_page(
            'custom-bulk-coupon-generator',
            'View Coupons',
            'View Coupons',
            'manage_options',
            'edit.php?post_type=shop_coupon'
        );
    }
    /**
     * Admin page content
    */
    public function custom_bulk_coupon_page() {
        
        // Bulk Coupon form generator
        require_once( BCC_PLUGIN_DIR . '/includes/bulk-coupon-generator.php' );
        
        // Fetch coupons
        require_once( BCC_PLUGIN_DIR . '/includes/bluk-fetch-records.php' );    
    }

    private function custom_generate_coupon( $customer_email, $product_ids, $discount_type = 'percent', $amount = '10', $usage_limit = 5 ) {
        $coupon_code = 'COUPON-' . wp_generate_password( 8, false );
        $coupon = new WC_Coupon();
        $coupon->set_code( $coupon_code );
        $coupon->set_discount_type( $discount_type );
        $coupon->set_amount( $amount );
        $coupon->set_individual_use( true );
        $coupon->set_email_restrictions( array( $customer_email ) );
        $coupon->set_product_ids( $product_ids );
        $coupon->set_usage_limit( $usage_limit );
        $coupon->save();
    
        $product_details = '';
    
        foreach ( $product_ids as $product_id ) {

            $product = wc_get_product( $product_id );
            if ( $product ) {
                // Get the product title and permalink
                $product_title = $product->get_name();
                $product_link = $product->get_permalink();
                $product_details .= "Product: " . $product_title . " - Link: " . $product_link . "\n";
            }
        }
    
        // Email content with product titles and links
        $email_content = "Here is your coupon: " . $coupon_code . "\n\n" . "Applicable Products:\n" . $product_details;
    
        // Send email to the user
        wp_mail( $customer_email, 'Your Special Coupon', $email_content );
    
        return $coupon_code;
    }

}

// Register activation and deactivation hooks
register_activation_hook( BCC_PLUGIN_FILE, array( 'Bulk_Coupon_Code_Generator', 'on_activation' ) );
register_deactivation_hook( BCC_PLUGIN_FILE, array( 'Bulk_Coupon_Code_Generator', 'on_deactivation' ) );

new Bulk_Coupon_Code_Generator();