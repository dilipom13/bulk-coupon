=== Bulk Coupon Code Generator ===
- Install Woo-commerce
- Create custom bulk coupon code generate plugin using WP standard.
- Assign specific customer and product, customer get mail with store URL with assign products
- Allowed coupon only assign customer.
- Track in back-end who will used coupon code.